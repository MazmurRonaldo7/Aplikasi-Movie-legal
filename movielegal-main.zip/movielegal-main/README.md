# movielegal
Aplikasi ini dibuat dengan bahasa pemrograman PHP versi 7.4.28, Bootstrap versi 4.6.0, font awesome versi 5.15.1 dan database MariaDB versi 10.4.22

<-- tata cara -->
tinggal restore file sql nya ke web server
