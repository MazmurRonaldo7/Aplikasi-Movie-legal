<style>
body {
    overflow: hidden;
}

.forbid {
    position: absolute;
    background: url(img/403.gif);
    background-repeat: no-repeat;
    background-size: cover;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 100;
}

.forbid1 {
    margin: 240px 17px auto auto;
    font-family: 'Raleway';
}
</style>
<div class="container-xxl forbid">
    <div class="container text-uppercase text-center">
        <a href="index.php" class="btn btn-login forbid1">Back To Home</a>
    </div>
</div>